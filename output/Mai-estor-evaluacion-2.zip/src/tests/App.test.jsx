import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { beforeEach, test, expect } from 'vitest';
import App from '../App';
import { getOrders } from '../data/adminStore';
beforeEach(() => localStorage.clear());
test('flujo integrado: registro, carrito, error, reintento y compra exitosa', async () => {
  const user = userEvent.setup(); render(<App />);
  await user.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]);
  await user.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]);
  await user.click(screen.getByRole('button', { name: 'Iniciar Sesión / Registro' }));
  await user.click(screen.getByRole('button', { name: /No tienes cuenta/ }));
  await user.type(screen.getByLabelText('Nombre Completo'), 'Camila Soto');
  await user.type(screen.getByLabelText('Correo Electrónico'), 'camila@example.com');
  await user.type(screen.getByLabelText('Contraseña'), 'demo');
  await user.type(screen.getByLabelText('Dirección'), 'Calle 123');
  await user.click(screen.getByRole('button', { name: 'Registrarse' }));
  await user.click(screen.getByRole('button', { name: /Carrito 2/ }));
  expect(within(screen.getByRole('table')).getAllByRole('row')).toHaveLength(2);
  await user.click(screen.getByRole('button', { name: 'Comprar ahora' }));
  expect(screen.getByLabelText('Nombre completo')).toHaveValue('Camila Soto');
  expect(screen.getByLabelText('Dirección de envío')).toHaveValue('Calle 123');
  await user.click(screen.getByLabelText(/Simular error/));
  await user.click(screen.getByRole('button', { name: /Confirmar compra/ }));
  expect(screen.getByRole('heading', { name: 'No se pudo realizar el pago' })).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Volver a Intentar el Pago' }));
  expect(screen.getByLabelText('Dirección de envío')).toHaveValue('Calle 123');
  await user.click(screen.getByRole('button', { name: /Confirmar compra/ }));
  expect(screen.getByRole('heading', { name: /Compra Realizada/ })).toBeInTheDocument();
  expect(screen.getByRole('button', { name: /Carrito 0/ })).toBeInTheDocument();
  expect(getOrders()).toHaveLength(1);
  expect(getOrders()[0]).toMatchObject({ email: 'camila@example.com', cliente: 'Camila Soto' });
}, 15000); // Flujo integrado con múltiples formularios e interacciones.
test('navega por detalle de producto, nosotros, blog y contacto', async () => {
  const user = userEvent.setup(); render(<App />);
  await user.click(screen.getAllByRole('button', { name: 'Ver detalle' })[0]);
  expect(screen.getByRole('heading', { name: 'Zelda: Tears of the Kingdom' })).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Volver al catálogo' }));
  await user.click(screen.getByRole('button', { name: 'Nosotros' }));
  expect(screen.getByRole('heading', { name: 'Nosotros' })).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Blog' }));
  await user.click(screen.getByRole('button', { name: /Leer Cómo elegir/ }));
  expect(screen.getByText(/clasificación por edades/)).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'Volver al blog' }));
  expect(screen.getAllByRole('article')).toHaveLength(2);
  await user.click(screen.getByRole('button', { name: 'Contacto' }));
  await user.type(screen.getByLabelText('Nombre'), 'Camila'); await user.type(screen.getByLabelText('Correo'), 'c@example.com');
  await user.type(screen.getByLabelText('Mensaje'), 'Consulta de prueba'); await user.click(screen.getByRole('button', { name: 'Validar mensaje' }));
  expect(screen.getByRole('status')).toHaveTextContent('no envía correos');
});
test('administrador actualiza precios del carrito y salir oculta su panel', async () => {
  const user = userEvent.setup(); render(<App />);
  expect(screen.queryByRole('button', { name: 'Panel Admin' })).not.toBeInTheDocument();
  await user.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]);
  await user.click(screen.getByRole('button', { name: 'Iniciar Sesión / Registro' }));
  await user.type(screen.getByLabelText('Correo Electrónico'), 'da@gmail.com'); await user.type(screen.getByLabelText('Contraseña'), 'aaa');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  await user.click(screen.getByRole('button', { name: 'Panel Admin' }));
  await user.click(within(screen.getByRole('navigation', { name: 'Administración' })).getByRole('button', { name: 'Productos', exact: true }));
  await user.click(screen.getByRole('button', { name: 'Editar Zelda: Tears of the Kingdom' }));
  await user.clear(screen.getByLabelText('Precio')); await user.type(screen.getByLabelText('Precio'), '1000');
  await user.click(screen.getByRole('button', { name: 'Guardar cambios' }));
  await user.click(screen.getByRole('button', { name: /Carrito 1/ }));
  expect(screen.getByText('Total: $1.000')).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'admin' })); await user.click(screen.getByRole('button', { name: 'Cerrar Sesión' }));
  expect(screen.queryByRole('button', { name: 'Panel Admin' })).not.toBeInTheDocument();
});


test('un catálogo vacío informa ausencia de productos y no carga indefinidamente', () => {
  localStorage.setItem('products', '[]'); render(<App />);
  expect(screen.getByRole('status')).toHaveTextContent('No hay productos disponibles');
  expect(screen.queryByText('Cargando productos...')).not.toBeInTheDocument();
});

test('editar perfil administrador sincroniza los datos del checkout', async () => {
  const user = userEvent.setup(); render(<App />);
  await user.click(screen.getAllByRole('button', { name: 'Añadir al Carrito' })[0]);
  await user.click(screen.getByRole('button', { name: 'Iniciar Sesión / Registro' }));
  await user.type(screen.getByLabelText('Correo Electrónico'), 'da@gmail.com');
  await user.type(screen.getByLabelText('Contraseña'), 'aaa');
  await user.click(screen.getByRole('button', { name: 'Ingresar' }));
  await user.click(screen.getByRole('button', { name: 'Panel Admin' }));
  await user.click(screen.getByRole('button', { name: 'Perfil administrador' }));
  await user.clear(screen.getByLabelText('Nombre'));
  await user.type(screen.getByLabelText('Nombre'), 'Administrador actualizado');
  await user.type(screen.getByLabelText('Dirección'), 'Calle Nueva 123');
  await user.click(screen.getByRole('button', { name: 'Guardar perfil' }));
  await user.click(screen.getByRole('button', { name: /Carrito 1/ }));
  await user.click(screen.getByRole('button', { name: 'Comprar ahora' }));
  expect(screen.getByLabelText('Nombre completo')).toHaveValue('Administrador actualizado');
  expect(screen.getByLabelText('Dirección de envío')).toHaveValue('Calle Nueva 123');
});
